"use client";

import { useState } from "react";
import { Phone, Mail, MapPin, Clock, Send, CheckCircle } from "lucide-react";

const services = [
  "USA LLC Formation + EIN",
  "UK LTD Formation",
  "ITIN Guidance",
  "Payment Setup (Stripe/Payoneer/Wise)",
  "Website & Landing Page",
  "Mobile App Development",
  "Facebook & Google Ads",
  "Digital Marketing & SEO",
  "Cyber Security",
  "USA eSIM Support",
  "Multiple Services",
];

export default function ContactSection() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    service: "",
    message: "",
  });
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (res.ok) {
        setSuccess(true);
        setForm({ name: "", email: "", phone: "", service: "", message: "" });
      } else {
        const data = await res.json();
        setError(data.error || "Something went wrong. Please try again.");
      }
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const contactInfo = [
    { icon: <Phone size={18} />, label: "Phone", value: "+1 (888) 123-4567", href: "tel:+18881234567" },
    { icon: <Mail size={18} />, label: "Email", value: "info@dolphintechhub.com", href: "mailto:info@dolphintechhub.com" },
    { icon: <MapPin size={18} />, label: "Address", value: "123 Business Avenue, Suite 100, New York, NY 10001, USA", href: "#" },
    { icon: <Clock size={18} />, label: "Hours", value: "Mon – Sat: 9:00 AM – 6:00 PM EST", href: "#" },
  ];

  return (
    <section id="contact" className="py-24" style={{ background: "#F8FAFC" }}>
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <p className="section-label mb-3">GET IN TOUCH</p>
          <h2 className="section-title mb-4">Start Your Journey Today</h2>
          <p className="section-subtitle max-w-xl mx-auto">
            Ready to launch your global business? Fill out the form below and our team will get
            back to you within 24 hours.
          </p>
        </div>

        <div className="grid lg:grid-cols-5 gap-10">
          {/* Left: Contact Info */}
          <div className="lg:col-span-2 space-y-6">
            {/* Info card */}
            <div
              className="rounded-2xl p-8 text-white relative overflow-hidden"
              style={{ background: "linear-gradient(135deg, #0B1F3A, #146EF5)" }}
            >
              <div className="absolute inset-0 dot-pattern pointer-events-none" style={{ opacity: 0.06 }} />
              <div className="relative z-10">
                <h3 className="text-xl font-bold mb-2">Contact Information</h3>
                <p className="text-sm mb-8" style={{ color: "rgba(255,255,255,0.7)" }}>
                  Our expert team is ready to assist you. Reach out through any channel below.
                </p>

                <div className="space-y-5">
                  {contactInfo.map((info, i) => (
                    <a
                      key={i}
                      href={info.href}
                      className="flex items-start gap-4 group"
                    >
                      <div
                        className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                        style={{ background: "rgba(255,255,255,0.12)" }}
                      >
                        {info.icon}
                      </div>
                      <div>
                        <div className="text-xs font-semibold mb-0.5" style={{ color: "rgba(255,255,255,0.5)" }}>
                          {info.label}
                        </div>
                        <div className="text-sm font-medium group-hover:text-cyan-300 transition-colors" style={{ color: "rgba(255,255,255,0.9)" }}>
                          {info.value}
                        </div>
                      </div>
                    </a>
                  ))}
                </div>

                {/* Social */}
                <div className="mt-8 pt-6 border-t border-white border-opacity-10">
                  <div className="text-xs font-semibold mb-3" style={{ color: "rgba(255,255,255,0.5)" }}>Follow Us</div>
                  <div className="flex gap-3">
                    {["f", "in", "tw", "ig"].map((s) => (
                      <a
                        key={s}
                        href="#"
                        className="w-9 h-9 rounded-lg flex items-center justify-center text-xs font-bold uppercase transition-all hover:scale-110"
                        style={{ background: "rgba(255,255,255,0.12)", color: "white" }}
                      >
                        {s}
                      </a>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right: Form */}
          <div className="lg:col-span-3">
            <div className="bg-white rounded-2xl p-8 border border-slate-100 shadow-sm">
              {success ? (
                <div className="text-center py-12">
                  <div
                    className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4"
                    style={{ background: "rgba(20,110,245,0.1)" }}
                  >
                    <CheckCircle size={32} style={{ color: "#146EF5" }} />
                  </div>
                  <h3 className="text-xl font-bold mb-2" style={{ color: "#0B1F3A" }}>
                    Message Sent!
                  </h3>
                  <p className="text-sm" style={{ color: "#64748B" }}>
                    Thank you for reaching out. Our team will contact you within 24 hours.
                  </p>
                  <button
                    onClick={() => setSuccess(false)}
                    className="mt-6 btn-primary"
                  >
                    Send Another Message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-sm font-semibold mb-1.5" style={{ color: "#0B1F3A" }}>
                        Full Name *
                      </label>
                      <input
                        type="text"
                        name="name"
                        value={form.name}
                        onChange={handleChange}
                        placeholder="John Smith"
                        required
                        className="form-input"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold mb-1.5" style={{ color: "#0B1F3A" }}>
                        Email Address *
                      </label>
                      <input
                        type="email"
                        name="email"
                        value={form.email}
                        onChange={handleChange}
                        placeholder="john@example.com"
                        required
                        className="form-input"
                      />
                    </div>
                  </div>

                  <div className="grid sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-sm font-semibold mb-1.5" style={{ color: "#0B1F3A" }}>
                        Phone Number
                      </label>
                      <input
                        type="tel"
                        name="phone"
                        value={form.phone}
                        onChange={handleChange}
                        placeholder="+1 (555) 000-0000"
                        className="form-input"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold mb-1.5" style={{ color: "#0B1F3A" }}>
                        Service Interested In *
                      </label>
                      <select
                        name="service"
                        value={form.service}
                        onChange={handleChange}
                        required
                        className="form-input"
                        style={{ cursor: "pointer" }}
                      >
                        <option value="">Select a service...</option>
                        {services.map((s) => (
                          <option key={s} value={s}>{s}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold mb-1.5" style={{ color: "#0B1F3A" }}>
                      Message *
                    </label>
                    <textarea
                      name="message"
                      value={form.message}
                      onChange={handleChange}
                      placeholder="Tell us about your business and what you need help with..."
                      required
                      rows={5}
                      className="form-input resize-none"
                    />
                  </div>

                  {error && (
                    <div className="rounded-lg p-3 text-sm" style={{ background: "#fef2f2", color: "#dc2626" }}>
                      {error}
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={loading}
                    className="btn-primary w-full justify-center text-base py-4"
                  >
                    {loading ? (
                      <span className="flex items-center gap-2">
                        <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        Sending...
                      </span>
                    ) : (
                      <>
                        Send Message <Send size={16} />
                      </>
                    )}
                  </button>

                  <p className="text-center text-xs" style={{ color: "#94A3B8" }}>
                    We respond within 24 hours · 100% Confidential · No Spam
                  </p>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
