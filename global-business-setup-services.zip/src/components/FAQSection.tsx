"use client";

import { useState } from "react";
import { ChevronDown } from "lucide-react";

const faqs = [
  {
    q: "How long does USA LLC formation take?",
    a: "LLC formation timelines vary by state. Most standard filings take 7–14 business days. Expedited options can be completed in 1–5 business days. We'll guide you on the best state and processing speed for your situation.",
  },
  {
    q: "Can I open a Stripe account without a USA address?",
    a: "Yes — with a properly formed USA LLC, you can open a Stripe account regardless of your country of residence. We help you set up everything correctly so your account gets approved without issues.",
  },
  {
    q: "What is an EIN and why do I need it?",
    a: "An EIN (Employer Identification Number) is a unique Tax ID issued by the IRS. You need it to open a US business bank account, set up Stripe or PayPal, hire employees, and file US taxes. We handle the complete EIN application process.",
  },
  {
    q: "Do I need to travel to the USA to form an LLC?",
    a: "No. The entire LLC formation process can be done remotely. You never need to set foot in the USA. We handle all filings, and you receive all documents electronically.",
  },
  {
    q: "What payment platforms can you help me set up?",
    a: "We provide guidance and setup support for Stripe, Payoneer and Wise. These three platforms cover most global payment needs — from accepting credit cards to receiving international bank transfers.",
  },
  {
    q: "What does the website development service include?",
    a: "Our website service includes custom design and development, mobile responsiveness, SEO optimization, fast loading, contact forms, and basic on-page content. We offer both ready-made templates and fully custom builds depending on your budget and needs.",
  },
  {
    q: "How does the Facebook Ads setup work?",
    a: "We create and configure your Meta Business Manager, install the Facebook Pixel on your website, set up your ad account with proper billing, and build and launch your first ad campaign — including targeting, creative guidance and budget recommendations.",
  },
  {
    q: "What is ITIN and who needs it?",
    a: "An ITIN (Individual Taxpayer Identification Number) is issued by the IRS for individuals who don't have or aren't eligible for a Social Security Number. It's needed for US tax filing purposes. We provide complete step-by-step guidance for the ITIN application process.",
  },
  {
    q: "What is the USA eSIM service?",
    a: "We help you get a permanent USA phone number via eSIM, which you can use globally on any compatible device. This is useful for business verification with Stripe, banks, and other US services that require a US phone number.",
  },
  {
    q: "Do you offer ongoing support after my business is set up?",
    a: "Yes. We offer ongoing support packages that include digital marketing management, SEO maintenance, cybersecurity monitoring, technical support and business consulting. We are a long-term partner, not just a one-time service provider.",
  },
];

export default function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section id="faq" className="py-24 bg-white">
      <div className="max-w-4xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <p className="section-label mb-3">FAQ</p>
          <h2 className="section-title mb-4">Frequently Asked Questions</h2>
          <p className="section-subtitle">
            Everything you need to know about our services and how we work.
          </p>
        </div>

        {/* FAQ Items */}
        <div className="space-y-3">
          {faqs.map((faq, i) => (
            <div key={i} className="faq-item">
              <button
                className="w-full flex items-center justify-between p-5 text-left transition-colors"
                style={{ color: openIndex === i ? "#146EF5" : "#0B1F3A" }}
                onClick={() => setOpenIndex(openIndex === i ? null : i)}
              >
                <span className="font-semibold text-sm md:text-base pr-4">{faq.q}</span>
                <ChevronDown
                  size={18}
                  className={`flex-shrink-0 transition-transform duration-300 ${openIndex === i ? "rotate-180" : ""}`}
                  style={{ color: "#146EF5" }}
                />
              </button>
              {openIndex === i && (
                <div
                  className="px-5 pb-5 text-sm leading-relaxed"
                  style={{ color: "#64748B" }}
                >
                  {faq.a}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-12">
          <p className="text-sm mb-4" style={{ color: "#64748B" }}>
            Still have questions? We&apos;re happy to help.
          </p>
          <a href="#contact" className="btn-primary">
            Contact Us
          </a>
        </div>
      </div>
    </section>
  );
}
