"use client";

import { useState, useEffect } from "react";
import { Menu, X, ChevronDown, Phone, Mail } from "lucide-react";
import Link from "next/link";

const services = [
  { label: "USA LLC Formation + EIN", href: "#services" },
  { label: "UK LTD Formation", href: "#services" },
  { label: "ITIN Guidance", href: "#services" },
  { label: "Payment Setup (Stripe/Payoneer/Wise)", href: "#services" },
  { label: "Website & Landing Page", href: "#services" },
  { label: "Mobile App Development", href: "#services" },
  { label: "Facebook & Google Ads", href: "#services" },
  { label: "Digital Marketing & SEO", href: "#services" },
  { label: "Cyber Security", href: "#services" },
  { label: "USA eSIM Support", href: "#services" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [servicesOpen, setServicesOpen] = useState(false);
  const [mobileServicesOpen, setMobileServicesOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = mobileOpen ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [mobileOpen]);

  const navLinks = [
    { label: "Home", href: "#home" },
    { label: "About Us", href: "#about" },
    { label: "Why Us", href: "#why-us" },
    { label: "FAQ", href: "#faq" },
    { label: "Contact", href: "#contact" },
  ];

  return (
    <>
      {/* Announcement Bar */}
      <div className="announcement-bar hidden md:block">
        <div className="max-w-7xl mx-auto px-4 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <span className="flex items-center gap-1.5">
              <Phone size={12} />
              +1 (888) 123-4567
            </span>
            <span className="flex items-center gap-1.5">
              <Mail size={12} />
              info@dolphintechhub.com
            </span>
          </div>
          <span>Mon – Sat: 9:00 AM – 6:00 PM EST</span>
        </div>
      </div>

      {/* Main Nav */}
      <nav className={`sticky-nav transition-all duration-300 ${scrolled ? "py-3" : "py-4"}`}>
        <div className="max-w-7xl mx-auto px-4 flex items-center justify-between gap-6">
          {/* Logo */}
          <Link href="#home" className="flex items-center gap-2.5 flex-shrink-0">
            <div
              className="w-9 h-9 rounded-lg flex items-center justify-center text-white font-black text-lg"
              style={{ background: "linear-gradient(135deg, #146EF5, #20C4D9)" }}
            >
              D
            </div>
            <div>
              <div className="font-black text-base leading-tight" style={{ color: "#0B1F3A" }}>
                Dolphin Tech Hub
              </div>
              <div className="text-xs font-medium" style={{ color: "#146EF5" }}>
                Start. Build. Grow Globally.
              </div>
            </div>
          </Link>

          {/* Desktop Nav Links */}
          <div className="hidden lg:flex items-center gap-8">
            <Link href="#home" className="nav-link">Home</Link>

            {/* Services Dropdown */}
            <div
              className="relative"
              onMouseEnter={() => setServicesOpen(true)}
              onMouseLeave={() => setServicesOpen(false)}
            >
              <button className="nav-link flex items-center gap-1">
                Services <ChevronDown size={14} className={`transition-transform ${servicesOpen ? "rotate-180" : ""}`} />
              </button>
              {servicesOpen && (
                <div
                  className="absolute top-full left-0 mt-2 w-72 bg-white rounded-xl border border-slate-100 shadow-xl py-2 z-50"
                  style={{ boxShadow: "0 16px 48px rgba(11,31,58,0.12)" }}
                >
                  {services.map((s) => (
                    <Link
                      key={s.label}
                      href={s.href}
                      className="block px-4 py-2.5 text-sm text-slate-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                      onClick={() => setServicesOpen(false)}
                    >
                      {s.label}
                    </Link>
                  ))}
                </div>
              )}
            </div>

            <Link href="#about" className="nav-link">About Us</Link>
            <Link href="#why-us" className="nav-link">Why Us</Link>
            <Link href="#faq" className="nav-link">FAQ</Link>
            <Link href="#contact" className="nav-link">Contact</Link>
          </div>

          {/* CTA */}
          <div className="hidden lg:flex items-center gap-3">
            <a href="#contact" className="btn-primary">
              Get Started
            </a>
          </div>

          {/* Mobile Toggle */}
          <button
            className="lg:hidden p-2 rounded-lg"
            style={{ color: "#0B1F3A" }}
            onClick={() => setMobileOpen(true)}
            aria-label="Open menu"
          >
            <Menu size={22} />
          </button>
        </div>
      </nav>

      {/* Mobile Overlay */}
      <div
        className={`mobile-overlay ${mobileOpen ? "open" : ""}`}
        onClick={() => setMobileOpen(false)}
      />

      {/* Mobile Menu */}
      <div className={`mobile-menu ${mobileOpen ? "open" : ""}`}>
        <div className="flex items-center justify-between p-5 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div
              className="w-8 h-8 rounded-lg flex items-center justify-center text-white font-black"
              style={{ background: "linear-gradient(135deg, #146EF5, #20C4D9)" }}
            >
              D
            </div>
            <span className="font-black text-sm" style={{ color: "#0B1F3A" }}>Dolphin Tech Hub</span>
          </div>
          <button onClick={() => setMobileOpen(false)} className="p-1.5 rounded-lg hover:bg-slate-100">
            <X size={20} />
          </button>
        </div>

        <div className="p-4 space-y-1">
          {navLinks.map((link) => (
            <Link
              key={link.label}
              href={link.href}
              className="block px-4 py-3 rounded-lg font-medium text-slate-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
              onClick={() => setMobileOpen(false)}
            >
              {link.label}
            </Link>
          ))}

          <div>
            <button
              className="w-full flex items-center justify-between px-4 py-3 rounded-lg font-medium text-slate-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
              onClick={() => setMobileServicesOpen(!mobileServicesOpen)}
            >
              <span>Services</span>
              <ChevronDown size={16} className={`transition-transform ${mobileServicesOpen ? "rotate-180" : ""}`} />
            </button>
            {mobileServicesOpen && (
              <div className="ml-4 space-y-0.5 border-l-2 border-blue-100 pl-3 mt-1">
                {services.map((s) => (
                  <Link
                    key={s.label}
                    href={s.href}
                    className="block px-3 py-2 text-sm text-slate-600 hover:text-blue-600 transition-colors"
                    onClick={() => setMobileOpen(false)}
                  >
                    {s.label}
                  </Link>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="p-4 border-t border-slate-100">
          <a
            href="#contact"
            className="btn-primary w-full justify-center"
            onClick={() => setMobileOpen(false)}
          >
            Get Started
          </a>
          <div className="mt-4 space-y-2">
            <a href="tel:+18881234567" className="flex items-center gap-2 text-sm text-slate-600">
              <Phone size={14} /> +1 (888) 123-4567
            </a>
            <a href="mailto:info@dolphintechhub.com" className="flex items-center gap-2 text-sm text-slate-600">
              <Mail size={14} /> info@dolphintechhub.com
            </a>
          </div>
        </div>
      </div>
    </>
  );
}
