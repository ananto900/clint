"use client";

import { ArrowRight, CheckCircle, Globe, Shield, Zap } from "lucide-react";

export default function HeroSection() {
  return (
    <section id="home" className="hero-section flex items-center" style={{ minHeight: "90vh" }}>
      {/* Decorative blobs */}
      <div
        className="absolute top-1/4 right-1/4 w-96 h-96 rounded-full pointer-events-none"
        style={{
          background: "radial-gradient(circle, rgba(20,110,245,0.18) 0%, transparent 70%)",
          filter: "blur(60px)",
        }}
      />
      <div
        className="absolute bottom-1/4 left-1/6 w-72 h-72 rounded-full pointer-events-none"
        style={{
          background: "radial-gradient(circle, rgba(32,196,217,0.12) 0%, transparent 70%)",
          filter: "blur(50px)",
        }}
      />

      <div className="relative z-10 max-w-7xl mx-auto px-4 py-20 w-full">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left: Text Content */}
          <div>
            {/* Badge */}
            <div className="inline-flex items-center gap-2 mb-6 px-4 py-2 rounded-full border text-sm font-semibold"
              style={{ borderColor: "rgba(32,196,217,0.4)", color: "#20C4D9", background: "rgba(32,196,217,0.08)" }}>
              <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse-slow" />
              Trusted by 500+ Global Entrepreneurs
            </div>

            <h1 className="font-black leading-tight mb-6"
              style={{ fontSize: "clamp(2.2rem, 5vw, 3.5rem)", color: "white", letterSpacing: "-0.03em" }}>
              Start Your Business.{" "}
              <span style={{ color: "#20C4D9" }}>Build Your</span>{" "}
              Digital Presence.{" "}
              <span className="gradient-text">Grow Globally.</span>
            </h1>

            <p className="mb-8 leading-relaxed" style={{ color: "rgba(255,255,255,0.72)", fontSize: "1.1rem", maxWidth: "520px" }}>
              Launch and scale your online business with professional LLC formation, EIN, payment
              solutions, websites, mobile apps, marketing and technology support — all through one
              trusted platform.
            </p>

            {/* Trust points */}
            <div className="flex flex-wrap gap-4 mb-8">
              {[
                "USA LLC & UK LTD",
                "Stripe & Payoneer Ready",
                "Full Digital Marketing",
              ].map((item) => (
                <div key={item} className="flex items-center gap-2 text-sm" style={{ color: "rgba(255,255,255,0.8)" }}>
                  <CheckCircle size={15} style={{ color: "#20C4D9" }} />
                  {item}
                </div>
              ))}
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-wrap gap-4">
              <a
                href="#contact"
                className="btn-primary text-base px-6 py-3.5"
                style={{ background: "#146EF5" }}
              >
                Get Started <ArrowRight size={18} />
              </a>
              <a
                href="#services"
                className="flex items-center gap-2 font-semibold text-base px-6 py-3.5 rounded-lg transition-all"
                style={{ color: "white", border: "2px solid rgba(255,255,255,0.25)" }}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLAnchorElement).style.background = "rgba(255,255,255,0.08)";
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLAnchorElement).style.background = "transparent";
                }}
              >
                Explore Services <ArrowRight size={18} />
              </a>
            </div>

            {/* Trust Badges */}
            <div className="mt-10 flex flex-wrap gap-6">
              {[
                { icon: <Globe size={16} />, label: "Global Support" },
                { icon: <Shield size={16} />, label: "Trusted Solutions" },
                { icon: <Zap size={16} />, label: "Expert Team" },
              ].map((b) => (
                <div key={b.label} className="flex items-center gap-2 text-sm"
                  style={{ color: "rgba(255,255,255,0.6)" }}>
                  <span style={{ color: "#20C4D9" }}>{b.icon}</span>
                  {b.label}
                </div>
              ))}
            </div>
          </div>

          {/* Right: Visual Card Grid */}
          <div className="hidden lg:block relative">
            <div className="relative">
              {/* Main visual frame */}
              <div
                className="rounded-2xl p-6 border"
                style={{
                  background: "rgba(255,255,255,0.04)",
                  borderColor: "rgba(255,255,255,0.08)",
                  backdropFilter: "blur(12px)",
                }}
              >
                {/* World map dot grid */}
                <div className="relative h-64 rounded-xl mb-4 overflow-hidden flex items-center justify-center"
                  style={{ background: "rgba(20,110,245,0.08)", border: "1px solid rgba(20,110,245,0.15)" }}>
                  <WorldMapSVG />
                </div>

                {/* Mini service pills */}
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { label: "LLC Formation", color: "#146EF5" },
                    { label: "UK LTD Setup", color: "#20C4D9" },
                    { label: "Payment Gateway", color: "#146EF5" },
                    { label: "Digital Marketing", color: "#20C4D9" },
                  ].map((item) => (
                    <div key={item.label}
                      className="flex items-center gap-2 px-3 py-2 rounded-lg"
                      style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.08)" }}>
                      <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: item.color }} />
                      <span className="text-xs font-medium" style={{ color: "rgba(255,255,255,0.8)" }}>{item.label}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Floating stat cards */}
              <div
                className="absolute -top-4 -right-4 rounded-xl px-4 py-3 shadow-lg"
                style={{ background: "white" }}
              >
                <div className="text-xl font-black" style={{ color: "#146EF5" }}>500+</div>
                <div className="text-xs text-slate-500 font-medium">Global Clients</div>
              </div>
              <div
                className="absolute -bottom-4 -left-4 rounded-xl px-4 py-3 shadow-lg"
                style={{ background: "white" }}
              >
                <div className="text-xl font-black" style={{ color: "#0B1F3A" }}>35+</div>
                <div className="text-xs text-slate-500 font-medium">Countries Served</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom fade */}
      <div
        className="absolute bottom-0 left-0 right-0 h-24 pointer-events-none"
        style={{ background: "linear-gradient(to bottom, transparent, #F8FAFC)" }}
      />
    </section>
  );
}

function WorldMapSVG() {
  return (
    <svg viewBox="0 0 800 400" className="w-full h-full opacity-80" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Simplified continent outlines */}
      {/* North America */}
      <path d="M80 80 L180 70 L220 90 L230 140 L200 180 L160 200 L120 190 L80 160 Z" fill="rgba(20,110,245,0.15)" stroke="#146EF5" strokeWidth="1.5" />
      {/* South America */}
      <path d="M160 220 L210 210 L230 260 L220 320 L190 360 L160 350 L140 300 L150 250 Z" fill="rgba(20,110,245,0.12)" stroke="#146EF5" strokeWidth="1.5" />
      {/* Europe */}
      <path d="M330 70 L390 65 L410 90 L400 120 L370 130 L340 120 L325 100 Z" fill="rgba(32,196,217,0.15)" stroke="#20C4D9" strokeWidth="1.5" />
      {/* Africa */}
      <path d="M330 140 L390 135 L420 170 L430 240 L410 300 L380 320 L350 310 L330 260 L320 200 L325 170 Z" fill="rgba(20,110,245,0.1)" stroke="#146EF5" strokeWidth="1.5" />
      {/* Asia */}
      <path d="M420 60 L560 55 L620 80 L650 110 L640 150 L590 170 L530 180 L470 170 L430 150 L410 110 Z" fill="rgba(32,196,217,0.12)" stroke="#20C4D9" strokeWidth="1.5" />
      {/* Australia */}
      <path d="M580 240 L650 230 L680 260 L670 300 L630 310 L590 300 L570 270 Z" fill="rgba(20,110,245,0.1)" stroke="#146EF5" strokeWidth="1.5" />

      {/* Connection lines */}
      <line x1="160" y1="130" x2="360" y2="95" stroke="#20C4D9" strokeWidth="0.8" strokeDasharray="4 4" opacity="0.6" />
      <line x1="360" y1="95" x2="530" y2="120" stroke="#20C4D9" strokeWidth="0.8" strokeDasharray="4 4" opacity="0.6" />
      <line x1="160" y1="130" x2="190" y2="240" stroke="#146EF5" strokeWidth="0.8" strokeDasharray="4 4" opacity="0.4" />
      <line x1="360" y1="200" x2="610" y2="265" stroke="#20C4D9" strokeWidth="0.8" strokeDasharray="4 4" opacity="0.4" />

      {/* Dot nodes */}
      {[
        [160, 130], [360, 95], [530, 120], [190, 240], [615, 265], [155, 165],
      ].map(([cx, cy], i) => (
        <circle key={i} cx={cx} cy={cy} r="5" fill="#146EF5" opacity="0.9" />
      ))}
      {[
        [160, 130], [360, 95], [530, 120],
      ].map(([cx, cy], i) => (
        <circle key={`outer-${i}`} cx={cx} cy={cy} r="9" fill="none" stroke="#146EF5" strokeWidth="1" opacity="0.4" />
      ))}

      {/* Grid dots */}
      {Array.from({ length: 12 }).map((_, row) =>
        Array.from({ length: 25 }).map((__, col) => (
          <circle
            key={`dot-${row}-${col}`}
            cx={col * 32 + 10}
            cy={row * 32 + 10}
            r="1"
            fill="rgba(255,255,255,0.2)"
          />
        ))
      )}
    </svg>
  );
}
