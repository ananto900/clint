"use client";

const steps = [
  {
    step: "01",
    title: "Initial Consultation",
    description: "Tell us about your business goals. We assess your needs and recommend the right services for your situation.",
  },
  {
    step: "02",
    title: "Service Selection",
    description: "Choose the services you need — LLC formation, payment setup, website, app, marketing or all of the above.",
  },
  {
    step: "03",
    title: "Expert Execution",
    description: "Our specialists handle everything — filings, development, campaigns and setup — with constant updates.",
  },
  {
    step: "04",
    title: "Launch & Grow",
    description: "Your business launches. We provide ongoing support, optimization and guidance as you grow globally.",
  },
];

export default function ProcessSection() {
  return (
    <section id="process" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <p className="section-label mb-3">HOW IT WORKS</p>
          <h2 className="section-title mb-4">Simple 4-Step Process</h2>
          <p className="section-subtitle max-w-xl mx-auto">
            From your first consultation to a fully operational global business — we make it simple,
            fast and stress-free.
          </p>
        </div>

        {/* Steps */}
        <div className="relative">
          {/* Connector line */}
          <div
            className="hidden lg:block absolute top-12 left-1/8 right-1/8 h-0.5 z-0"
            style={{ background: "linear-gradient(90deg, #146EF5, #20C4D9)", opacity: 0.3 }}
          />

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 relative z-10">
            {steps.map((step, i) => (
              <div key={i} className="process-step">
                {/* Step circle */}
                <div
                  className="w-20 h-20 rounded-full flex items-center justify-center font-black text-2xl text-white relative mb-4"
                  style={{ background: "linear-gradient(135deg, #0B1F3A, #146EF5)" }}
                >
                  {step.step}
                  <div
                    className="absolute inset-0 rounded-full animate-pulse-slow"
                    style={{ background: "radial-gradient(circle, rgba(20,110,245,0.3), transparent)", transform: "scale(1.3)" }}
                  />
                </div>
                <h3 className="font-bold text-base" style={{ color: "#0B1F3A" }}>
                  {step.title}
                </h3>
                <p className="text-sm leading-relaxed" style={{ color: "#64748B" }}>
                  {step.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
