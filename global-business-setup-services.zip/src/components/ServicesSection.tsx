"use client";

import { ArrowRight, Building2, FileText, CreditCard, Globe, Smartphone, Megaphone, TrendingUp, Shield, Wifi, BadgeCheck } from "lucide-react";

const services = [
  {
    number: "01",
    icon: <Building2 size={28} />,
    title: "USA LLC Formation + EIN",
    description:
      "Complete Limited Liability Company setup in the USA with official EIN (Tax ID) from the Internal Revenue Service. We handle all paperwork and filings.",
    features: ["State filing & registration", "EIN from IRS", "Operating Agreement", "Registered Agent"],
    color: "#146EF5",
  },
  {
    number: "02",
    icon: <FileText size={28} />,
    title: "UK LTD Formation",
    description:
      "Professional UK Limited Company formation through Companies House. Get your business established in the United Kingdom quickly and compliantly.",
    features: ["Companies House filing", "Certificate of Incorporation", "Memorandum & Articles", "Director setup"],
    color: "#20C4D9",
  },
  {
    number: "03",
    icon: <BadgeCheck size={28} />,
    title: "ITIN Complete Guidance",
    description:
      "Full step-by-step guidance for obtaining your Individual Taxpayer Identification Number (ITIN) from the IRS — even without a Social Security Number.",
    features: ["Form W-7 preparation", "Document checklist", "IRS submission guidance", "Status tracking"],
    color: "#146EF5",
  },
  {
    number: "04",
    icon: <CreditCard size={28} />,
    title: "Payment Setup",
    description:
      "Get set up with Stripe, Payoneer and Wise to accept global payments professionally. We guide you through account creation, verification and integration.",
    features: ["Stripe account setup", "Payoneer verification", "Wise business account", "Payment integration"],
    color: "#20C4D9",
  },
  {
    number: "05",
    icon: <Globe size={28} />,
    title: "Website & Landing Page",
    description:
      "Professional website and high-converting landing page development. From ready-made solutions to fully custom designs built for results.",
    features: ["Custom design", "Mobile responsive", "SEO optimized", "Fast loading"],
    color: "#146EF5",
  },
  {
    number: "06",
    icon: <Smartphone size={28} />,
    title: "Mobile App Development",
    description:
      "Android and iOS app development from basic to advanced. We build native and cross-platform apps that deliver exceptional user experiences.",
    features: ["iOS & Android", "React Native / Flutter", "UI/UX Design", "App Store submission"],
    color: "#20C4D9",
  },
  {
    number: "07",
    icon: <Megaphone size={28} />,
    title: "Facebook & Google Ads",
    description:
      "Complete Meta Business Manager setup, Facebook Pixel installation, and your first campaign configured and ready to generate leads and sales.",
    features: ["Meta Business Manager", "Facebook Pixel setup", "Google Ads account", "1 Campaign setup"],
    color: "#146EF5",
  },
  {
    number: "08",
    icon: <TrendingUp size={28} />,
    title: "Digital Marketing & SEO",
    description:
      "Comprehensive digital marketing strategy, SEO optimization, content planning and advertising guidance to grow your business online consistently.",
    features: ["SEO strategy", "Content planning", "Analytics setup", "Growth roadmap"],
    color: "#20C4D9",
  },
  {
    number: "09",
    icon: <Shield size={28} />,
    title: "Cyber Security Support",
    description:
      "Protect your business from cyber threats with professional security assessments, best practice implementation and ongoing security guidance.",
    features: ["Security audit", "SSL & encryption", "Threat monitoring", "Best practices"],
    color: "#146EF5",
  },
  {
    number: "10",
    icon: <Wifi size={28} />,
    title: "USA Permanent eSIM",
    description:
      "Get a permanent USA phone number and eSIM for your business operations, enabling you to receive calls and SMS from the United States globally.",
    features: ["USA number", "eSIM setup", "Global roaming", "Business verification"],
    color: "#20C4D9",
  },
];

export default function ServicesSection() {
  return (
    <section id="services" className="py-24" style={{ background: "#F8FAFC" }}>
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <p className="section-label mb-3">WHAT WE OFFER</p>
          <h2 className="section-title mb-4">Our Core Services</h2>
          <p className="section-subtitle max-w-2xl mx-auto">
            End-to-end solutions to start, build and grow your online business — from company
            formation to digital marketing and cybersecurity.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service) => (
            <div key={service.number} className="service-card group">
              {/* Number + Icon */}
              <div className="flex items-start justify-between mb-5">
                <div
                  className="w-14 h-14 rounded-xl flex items-center justify-center transition-transform group-hover:scale-110"
                  style={{ background: `${service.color}15`, color: service.color }}
                >
                  {service.icon}
                </div>
                <span
                  className="text-4xl font-black opacity-10 group-hover:opacity-20 transition-opacity"
                  style={{ color: service.color }}
                >
                  {service.number}
                </span>
              </div>

              {/* Content */}
              <h3
                className="text-lg font-bold mb-3"
                style={{ color: "#0B1F3A" }}
              >
                {service.title}
              </h3>
              <p className="text-sm leading-relaxed mb-5" style={{ color: "#64748B" }}>
                {service.description}
              </p>

              {/* Features */}
              <ul className="space-y-1.5 mb-6">
                {service.features.map((f) => (
                  <li key={f} className="flex items-center gap-2 text-sm" style={{ color: "#475569" }}>
                    <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: service.color }} />
                    {f}
                  </li>
                ))}
              </ul>

              {/* Link */}
              <a
                href="#contact"
                className="inline-flex items-center gap-1.5 text-sm font-semibold transition-all group-hover:gap-3"
                style={{ color: service.color }}
              >
                Learn More <ArrowRight size={14} />
              </a>
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-14">
          <a href="#contact" className="btn-primary text-base px-8 py-4">
            Get Started with Any Service <ArrowRight size={18} />
          </a>
        </div>
      </div>
    </section>
  );
}
