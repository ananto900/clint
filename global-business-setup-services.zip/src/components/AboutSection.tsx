"use client";

import { CheckCircle, ArrowRight } from "lucide-react";
import Image from "next/image";

const points = [
  "Over 500 businesses launched across 35+ countries",
  "End-to-end support from formation to marketing",
  "Transparent process with zero hidden fees",
  "Dedicated expert team for every client",
  "Fast turnaround — most services in days, not weeks",
  "Ongoing support after your business is live",
];

export default function AboutSection() {
  return (
    <section id="about" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left: Image */}
          <div className="relative">
            <div className="relative rounded-2xl overflow-hidden" style={{ aspectRatio: "4/3" }}>
              <Image
                src="https://images.pexels.com/photos/7693700/pexels-photo-7693700.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
                alt="Professional business team at Dolphin Tech Hub"
                fill
                className="object-cover"
              />
              {/* Overlay accent */}
              <div
                className="absolute inset-0"
                style={{ background: "linear-gradient(135deg, rgba(11,31,58,0.2) 0%, transparent 60%)" }}
              />
            </div>

            {/* Floating stat */}
            <div
              className="absolute -bottom-5 -right-5 rounded-2xl p-5 shadow-xl border border-slate-100"
              style={{ background: "white" }}
            >
              <div className="text-3xl font-black mb-0.5" style={{ color: "#146EF5" }}>98%</div>
              <div className="text-sm font-medium" style={{ color: "#64748B" }}>Client Satisfaction Rate</div>
              <div className="flex mt-2">
                {Array.from({ length: 5 }).map((_, i) => (
                  <span key={i} className="text-yellow-400 text-lg">★</span>
                ))}
              </div>
            </div>

            {/* Dot pattern decoration */}
            <div
              className="absolute -top-5 -left-5 w-32 h-32 rounded-xl dot-pattern pointer-events-none"
              style={{ opacity: 0.4 }}
            />
          </div>

          {/* Right: Content */}
          <div>
            <p className="section-label mb-3">ABOUT US</p>
            <h2 className="section-title mb-5">
              Your Trusted Partner for{" "}
              <span className="gradient-text">Global Business Success</span>
            </h2>
            <p className="section-subtitle mb-5">
              We are a team of business, legal and digital experts helping entrepreneurs worldwide
              turn their ideas into successful online businesses. From company formation and payment
              setup to digital growth, we provide complete support at every step of your journey.
            </p>
            <p className="section-subtitle mb-8">
              Whether you&apos;re starting from scratch or scaling an existing venture, Dolphin Tech Hub
              gives you the tools, knowledge and expert support to thrive in the global marketplace.
            </p>

            {/* Checklist */}
            <ul className="space-y-3 mb-10">
              {points.map((point) => (
                <li key={point} className="flex items-start gap-3">
                  <CheckCircle size={18} className="flex-shrink-0 mt-0.5" style={{ color: "#146EF5" }} />
                  <span className="text-sm font-medium" style={{ color: "#374151" }}>{point}</span>
                </li>
              ))}
            </ul>

            <a href="#contact" className="btn-primary">
              Learn More About Us <ArrowRight size={17} />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
