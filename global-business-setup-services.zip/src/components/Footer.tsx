"use client";

import { Phone, Mail, MapPin, ArrowRight } from "lucide-react";

const quickLinks = ["Home", "About Us", "Services", "Blog", "FAQ", "Contact"];
const serviceLinks = [
  "USA LLC Formation",
  "UK LTD Formation",
  "EIN / Tax ID Assistance",
  "Payment Setup",
  "Website Development",
  "Digital Marketing",
  "Google Ads Management",
  "Cybersecurity Solutions",
];

export default function Footer() {
  return (
    <footer style={{ background: "#0B1F3A" }}>
      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-4 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-10">
          {/* Brand */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-2.5 mb-4">
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-black text-xl"
                style={{ background: "linear-gradient(135deg, #146EF5, #20C4D9)" }}
              >
                D
              </div>
              <div>
                <div className="font-black text-base text-white">Dolphin Tech Hub</div>
                <div className="text-xs font-medium" style={{ color: "#20C4D9" }}>
                  Start. Build. Grow Globally.
                </div>
              </div>
            </div>
            <p className="text-sm leading-relaxed mb-6" style={{ color: "rgba(255,255,255,0.5)" }}>
              We help entrepreneurs worldwide build and grow their online businesses with smart solutions
              and expert support — from company formation to digital marketing and technology.
            </p>

            {/* Social Links */}
            <div className="flex gap-3 mb-6">
              {[
                { label: "f", href: "#" },
                { label: "in", href: "#" },
                { label: "tw", href: "#" },
                { label: "ig", href: "#" },
              ].map((s) => (
                <a
                  key={s.label}
                  href={s.href}
                  className="w-9 h-9 rounded-lg flex items-center justify-center text-xs font-bold uppercase transition-all hover:scale-110"
                  style={{ background: "rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.6)" }}
                  onMouseEnter={(e) => {
                    (e.currentTarget as HTMLAnchorElement).style.background = "#146EF5";
                    (e.currentTarget as HTMLAnchorElement).style.color = "white";
                  }}
                  onMouseLeave={(e) => {
                    (e.currentTarget as HTMLAnchorElement).style.background = "rgba(255,255,255,0.08)";
                    (e.currentTarget as HTMLAnchorElement).style.color = "rgba(255,255,255,0.6)";
                  }}
                >
                  {s.label}
                </a>
              ))}
            </div>

            {/* Contact mini */}
            <div className="space-y-2">
              <a href="tel:+18881234567" className="flex items-center gap-2 text-sm" style={{ color: "rgba(255,255,255,0.55)" }}>
                <Phone size={13} style={{ color: "#20C4D9" }} /> +1 (888) 123-4567
              </a>
              <a href="mailto:info@dolphintechhub.com" className="flex items-center gap-2 text-sm" style={{ color: "rgba(255,255,255,0.55)" }}>
                <Mail size={13} style={{ color: "#20C4D9" }} /> info@dolphintechhub.com
              </a>
              <div className="flex items-start gap-2 text-sm" style={{ color: "rgba(255,255,255,0.55)" }}>
                <MapPin size={13} className="mt-0.5 flex-shrink-0" style={{ color: "#20C4D9" }} />
                <span>123 Business Avenue, Suite 100, New York, NY 10001, USA</span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-bold text-sm text-white mb-4">Quick Links</h4>
            {quickLinks.map((link) => (
              <a key={link} href={`#${link.toLowerCase().replace(" ", "-")}`} className="footer-link hover:pl-2 transition-all">
                &rsaquo; {link}
              </a>
            ))}
          </div>

          {/* Services */}
          <div>
            <h4 className="font-bold text-sm text-white mb-4">Our Services</h4>
            {serviceLinks.map((link) => (
              <a key={link} href="#services" className="footer-link hover:pl-2 transition-all">
                &rsaquo; {link}
              </a>
            ))}
          </div>

          {/* Newsletter */}
          <div>
            <h4 className="font-bold text-sm text-white mb-2">Newsletter</h4>
            <p className="text-sm mb-4" style={{ color: "rgba(255,255,255,0.5)" }}>
              Subscribe for updates and business tips.
            </p>
            <div className="flex gap-2">
              <input
                type="email"
                placeholder="Your email"
                className="flex-1 px-3 py-2.5 rounded-lg text-sm outline-none"
                style={{ background: "rgba(255,255,255,0.08)", color: "white", border: "1px solid rgba(255,255,255,0.1)" }}
              />
              <button
                className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 transition-all hover:scale-110"
                style={{ background: "#146EF5" }}
              >
                <ArrowRight size={16} color="white" />
              </button>
            </div>

            {/* Mon - Sat */}
            <div className="mt-6 p-4 rounded-xl" style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.06)" }}>
              <div className="text-xs font-semibold text-white mb-1">Business Hours</div>
              <div className="text-sm" style={{ color: "rgba(255,255,255,0.5)" }}>Mon – Sat: 9:00 AM – 6:00 PM</div>
              <div className="text-sm" style={{ color: "rgba(255,255,255,0.5)" }}>Eastern Standard Time (EST)</div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t" style={{ borderColor: "rgba(255,255,255,0.06)" }}>
        <div className="max-w-7xl mx-auto px-4 py-5 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-sm" style={{ color: "rgba(255,255,255,0.35)" }}>
            © 2024 Dolphin Tech Hub. All Rights Reserved.
          </p>
          <div className="flex gap-6">
            <a href="#" className="text-sm transition-colors hover:text-white" style={{ color: "rgba(255,255,255,0.35)" }}>
              Privacy Policy
            </a>
            <a href="#" className="text-sm transition-colors hover:text-white" style={{ color: "rgba(255,255,255,0.35)" }}>
              Terms of Service
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
