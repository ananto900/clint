"use client";

const testimonials = [
  {
    name: "James Richardson",
    role: "E-commerce Entrepreneur",
    country: "🇺🇸 United States",
    rating: 5,
    text: "Dolphin Tech Hub helped me set up my LLC, EIN and Stripe account within just a few days. The process was smooth, transparent and professional. My business is now running globally!",
    avatar: "JR",
    color: "#146EF5",
  },
  {
    name: "Sarah Mitchell",
    role: "Freelance Digital Marketer",
    country: "🇬🇧 United Kingdom",
    rating: 5,
    text: "From UK LTD formation to my Wise account and website launch — everything was handled perfectly. I can't believe how seamless the whole process was. Highly recommend!",
    avatar: "SM",
    color: "#20C4D9",
  },
  {
    name: "Ahmed Al-Hassan",
    role: "SaaS Founder",
    country: "🇦🇪 UAE",
    rating: 5,
    text: "I was amazed by the level of expertise. They helped with my LLC, set up payment processing and built my landing page. The team is responsive, knowledgeable and truly global.",
    avatar: "AA",
    color: "#0B1F3A",
  },
  {
    name: "Priya Sharma",
    role: "Online Business Owner",
    country: "🇮🇳 India",
    rating: 5,
    text: "Getting a USA LLC and Stripe account seemed impossible before Dolphin Tech Hub. They made it effortless. Now I accept payments worldwide and my business has grown 3x.",
    avatar: "PS",
    color: "#146EF5",
  },
  {
    name: "Carlos Mendoza",
    role: "Digital Agency Owner",
    country: "🇲🇽 Mexico",
    rating: 5,
    text: "The Facebook Ads and Google Ads setup service was exceptional. Our first campaign generated leads within 48 hours. The ROI has been incredible. Team knows their craft.",
    avatar: "CM",
    color: "#20C4D9",
  },
  {
    name: "Fatima Al-Zahra",
    role: "Startup Founder",
    country: "🇸🇦 Saudi Arabia",
    rating: 5,
    text: "From ITIN guidance to mobile app development — Dolphin Tech Hub delivered everything promised and more. Professional, fast and affordable. My go-to business partner.",
    avatar: "FA",
    color: "#0B1F3A",
  },
];

export default function TestimonialsSection() {
  return (
    <section id="testimonials" className="py-24" style={{ background: "#F8FAFC" }}>
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <p className="section-label mb-3">CLIENT STORIES</p>
          <h2 className="section-title mb-4">What Our Clients Say</h2>
          <p className="section-subtitle max-w-xl mx-auto">
            Real results from real entrepreneurs around the world who trusted Dolphin Tech Hub.
          </p>
        </div>

        {/* Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <div key={i} className="testimonial-card card-hover">
              {/* Stars */}
              <div className="flex mb-4">
                {Array.from({ length: t.rating }).map((_, si) => (
                  <span key={si} className="text-yellow-400 text-lg">★</span>
                ))}
              </div>

              {/* Quote */}
              <p className="text-sm leading-relaxed mb-6" style={{ color: "#374151" }}>
                &ldquo;{t.text}&rdquo;
              </p>

              {/* Author */}
              <div className="flex items-center gap-3 pt-4 border-t border-slate-100">
                <div
                  className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm flex-shrink-0"
                  style={{ background: t.color }}
                >
                  {t.avatar}
                </div>
                <div>
                  <div className="font-semibold text-sm" style={{ color: "#0B1F3A" }}>{t.name}</div>
                  <div className="text-xs" style={{ color: "#64748B" }}>{t.role}</div>
                  <div className="text-xs mt-0.5">{t.country}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
