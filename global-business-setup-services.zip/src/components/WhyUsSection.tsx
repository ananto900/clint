"use client";

import { Target, Shield, HeadphonesIcon, Globe, TrendingUp, Clock } from "lucide-react";

const reasons = [
  {
    icon: <Target size={30} />,
    title: "Result Driven",
    description:
      "We focus on strategies that deliver real, measurable results for your business — not just activity.",
  },
  {
    icon: <Shield size={30} />,
    title: "Secure & Reliable",
    description:
      "We ensure security, compliance and peace of mind for your business at every stage.",
  },
  {
    icon: <HeadphonesIcon size={30} />,
    title: "Expert Support",
    description:
      "Our specialists are always available to guide you, answer questions and resolve challenges fast.",
  },
  {
    icon: <Globe size={30} />,
    title: "Global Perspective",
    description:
      "We understand global markets and help you build a strong, credible international presence.",
  },
  {
    icon: <TrendingUp size={30} />,
    title: "Growth Focused",
    description:
      "We don't just set up your business — we help you grow it sustainably and profitably.",
  },
  {
    icon: <Clock size={30} />,
    title: "Fast Turnaround",
    description:
      "Most services delivered in days, not weeks. We value your time and move at the speed of business.",
  },
];

export default function WhyUsSection() {
  return (
    <section id="why-us" className="py-24" style={{ background: "#F8FAFC" }}>
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <p className="section-label mb-3">WHY CHOOSE US</p>
          <h2 className="section-title mb-4">We Focus on Your Growth</h2>
          <p className="section-subtitle max-w-2xl mx-auto">
            Six reasons why hundreds of entrepreneurs from around the world choose Dolphin Tech Hub
            as their trusted business and technology partner.
          </p>
        </div>

        {/* Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {reasons.map((reason, i) => (
            <div key={i} className="why-card group">
              {/* Icon */}
              <div
                className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-5 transition-all group-hover:scale-110"
                style={{ background: "linear-gradient(135deg, rgba(20,110,245,0.1), rgba(32,196,217,0.1))", color: "#146EF5" }}
              >
                {reason.icon}
              </div>
              <h3 className="text-lg font-bold mb-3" style={{ color: "#0B1F3A" }}>
                {reason.title}
              </h3>
              <p className="text-sm leading-relaxed" style={{ color: "#64748B" }}>
                {reason.description}
              </p>
            </div>
          ))}
        </div>

        {/* Bottom Banner */}
        <div
          className="mt-16 rounded-2xl p-8 md:p-12 text-center relative overflow-hidden"
          style={{ background: "linear-gradient(135deg, #0B1F3A 0%, #146EF5 100%)" }}
        >
          <div
            className="absolute inset-0 pointer-events-none dot-pattern"
            style={{ opacity: 0.06 }}
          />
          <div className="relative z-10">
            <h3 className="text-white font-bold text-2xl md:text-3xl mb-3">
              Ready to Start Your Global Business Journey?
            </h3>
            <p className="text-blue-100 mb-6 max-w-xl mx-auto">
              Join 500+ entrepreneurs who trusted Dolphin Tech Hub to launch and grow their
              businesses internationally.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <a
                href="#contact"
                className="px-7 py-3.5 rounded-lg font-semibold bg-white transition-all hover:shadow-lg hover:scale-105"
                style={{ color: "#146EF5" }}
              >
                Get Started Today
              </a>
              <a
                href="#services"
                className="px-7 py-3.5 rounded-lg font-semibold border-2 border-white text-white transition-all hover:bg-white hover:text-blue-600"
              >
                View All Services
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
