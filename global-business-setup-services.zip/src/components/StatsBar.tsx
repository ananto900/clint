"use client";

import { Users, Globe, Briefcase, Star } from "lucide-react";

const stats = [
  { icon: <Users size={28} />, number: "500+", label: "Happy Clients" },
  { icon: <Globe size={28} />, number: "35+", label: "Countries Served" },
  { icon: <Briefcase size={28} />, number: "1,200+", label: "Projects Completed" },
  { icon: <Star size={28} />, number: "98%", label: "Client Satisfaction" },
];

export default function StatsBar() {
  return (
    <section className="stats-bar py-10 relative z-20">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-0 lg:divide-x lg:divide-slate-100">
          {stats.map((stat, i) => (
            <div key={i} className="flex flex-col items-center text-center px-6 py-2">
              <div className="mb-3" style={{ color: "#146EF5" }}>
                {stat.icon}
              </div>
              <div
                className="font-black text-3xl mb-1"
                style={{ color: "#0B1F3A", letterSpacing: "-0.03em" }}
              >
                {stat.number}
              </div>
              <div className="text-sm font-medium" style={{ color: "#64748B" }}>
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
