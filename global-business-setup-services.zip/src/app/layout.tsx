import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Dolphin Tech Hub | Start. Build. Grow Globally.",
  description:
    "Start, launch and grow your online business with professional LLC formation, EIN, UK LTD, payment solutions, websites, mobile apps, digital marketing and technology support — all through one trusted platform.",
  keywords:
    "USA LLC formation, EIN, UK LTD, ITIN, Stripe setup, Payoneer, Wise, website development, mobile app, digital marketing, SEO, Facebook Ads, Google Ads, cybersecurity, USA eSIM",
  openGraph: {
    title: "Dolphin Tech Hub | Start. Build. Grow Globally.",
    description:
      "Your trusted partner for global business formation, digital presence and growth.",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="scroll-smooth">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Manrope:wght@400;500;600;700;800&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="antialiased" style={{ fontFamily: "'Inter', 'Manrope', system-ui, sans-serif" }}>
        {children}
      </body>
    </html>
  );
}
